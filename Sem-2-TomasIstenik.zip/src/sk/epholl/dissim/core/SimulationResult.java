package sk.epholl.dissim.core;

/**
 * Created by Tomáš on 26.03.2016.
 */
public interface SimulationResult {
}
